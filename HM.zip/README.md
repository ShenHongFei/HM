# HM 槐盟(大连高校环境联盟)	网站

![LOGO](http://tva2.sinaimg.cn/crop.0.0.180.180.180/a121378fjw1e8qgp5bmzyj2050050aa8.jpg)


[大连高校环境联盟-百度百科](http://baike.baidu.com/link?url=VhFPgFwxN_0WM8DWqC9YEGVTLZsLpFmHSPlwEIb-g4IUESdx3CdnKhZ-rlQHtzi2qMhNiWunTaqiviOzQXqJkdi1YR32bL0sECsj2UJtIMW1x2Sig6Fg2xXBhooWa1yNb2WNoWSZwFKcpdrKx932fLYaoIl01Gbkt3p5LIAhrWayhrr4vITOzAFIlx1VHeQs)

---

##网站
http://shenhongfei.site/HM

其它网页访问方法

http://shenhongfei.site/HM/{html文件名}

##后端接口
使用Postman发送HTTP请求并查看响应

https://www.getpostman.com/

导入以下接口

https://www.getpostman.com/collections/4d2a4366f2dd99382a03

##码云&GitHub
GitHub

https://github.com/shenhongfei/HM

码云

https://git.oschina.net/shenhongfei/HM




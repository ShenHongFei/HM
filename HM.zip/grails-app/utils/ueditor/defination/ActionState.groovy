package ueditor.defination;

public enum ActionState {
	UNKNOW_ERROR
}

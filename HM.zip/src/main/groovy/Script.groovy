import hm.User

new User(username:'aaa',password:'bbb',role:User.Role.GUEST).save()
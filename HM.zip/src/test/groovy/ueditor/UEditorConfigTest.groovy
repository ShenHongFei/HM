package ueditor

import spock.lang.Specification
import ueditor.defination.ActionMap

class UEditorConfigTest extends Specification{
    void "get json config test"(){
        expect:
            println new UEditorConfig().cfgObj.toString()
    }
}
